<template lang="pug">
  #header
    ul
     li.company
      | GFGM
     li
      a(href="/") Home
     li
      a(href="#" @click='fetchAllArticles()') Refresh
  #main
   div.loading(v-if="loading")
    hr
     h4 Loading..
    hr
   div(v-if="allArticles")
    div.magi(v-for="user in allArticles")
      UserCard(
        :blogimg='user.avatar'
        :id='user.id'
        :username='user.username'
        :time='user.time'
        :title='user.title'
        :summary='user.summary'
        :category='user.category'
      )
</template>

<script>
import UserCard from './components/Article.vue';

export default {
  name: 'App',
  components: {
    UserCard,
  },
  data() {
    return {
      loading: false,
      allArticles: null,
    };
  },
  created() {
    // watch the params of the route to fetch the data again
    this.$watch(
      () => this.$route.params,
      () => {
        this.fetchAllArticles()
      },
      // fetch the data when the view is created and the data is
      // already being observed
      { immediate: true }
    )
  },
  methods: {
   fetchAllArticles() {
     this.loading = true
     fetch('http://localhost:3000/article',{
      method: "GET",
      headers: {
          "content-type": 'application/json',        
        },      
     })
     .then((response) => {
          response.json().then((data) => {
            console.log(data)
            this.allArticles = data;

          });
      })
      .catch((err) => {
          console.error(err);
        });
   }
  },
};
</script>
<style lang="stylus">
 #header
  position:absolute
  top:0px 
  left:0px 
  height:60px
  right:0px
  overflow:hidden
 ul
  list-style-type: none
  margin: 0
  padding: 0
  overflow: hidden
  background-color: #333
 li
  float: left
 li a
  display: block
  color: white
  text-align: center
  padding: 14px 16px
  text-decoration: none
 li a:hover
  background-color:crimson
 .company
  display: block
  color: white
  text-align: center
  padding: 14px 16px
 #main 
  position:absolute
  
  top:60px
  bottom:60px
  left:0px
  right:0px
  overflow:auto
  .col
    width:25%
  .magi
    float:left
    width:23%
</style>